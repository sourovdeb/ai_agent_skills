<?php
/**
 * 404 — not found.
 *
 * @package Sourov
 */

get_header();
?>

<div class="content-area no-sidebar">
	<div class="content-wrap">
		<div class="error-404">
			<p class="code">404</p>
			<h1><?php esc_html_e( 'That page went missing.', 'sourov' ); ?></h1>
			<p><?php esc_html_e( 'The page you were looking for isn’t here — try a search or head back home.', 'sourov' ); ?></p>
			<div style="max-width:420px;margin:24px auto;">
				<?php get_search_form(); ?>
			</div>
			<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to home', 'sourov' ); ?></a>
		</div>
	</div>
</div>

<?php get_footer(); ?>
