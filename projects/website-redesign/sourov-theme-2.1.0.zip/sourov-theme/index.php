<?php
namespace Sourov;

/**
 * Main template. Front page: hero → pillars → latest writing → AI strip.
 * Blog index and fallbacks: standard card grid.
 *
 * @package Sourov
 */

get_header();

$is_front = is_front_page() && ! is_paged();
?>

<?php if ( $is_front ) : ?>

	<section class="hero" data-screen-label="Home">
		<?php $texture = SOUROV_DIR . '/assets/img/hero-texture.svg'; ?>
		<?php if ( file_exists( $texture ) ) : ?>
			<div class="hero__texture" aria-hidden="true">
				<img src="<?php echo esc_url( SOUROV_URI . '/assets/img/hero-texture.svg' ); ?>" alt="" loading="eager" decoding="async">
			</div>
		<?php endif; ?>
		<div class="hero__inner">
			<p class="hero__eyebrow"><?php echo esc_html( Customizer::get( 'hero_eyebrow' ) ); ?></p>
			<h1 class="hero__title"><?php echo esc_html( Customizer::get( 'hero_title' ) ); ?></h1>
			<p class="hero__excerpt"><?php echo esc_html( Customizer::get( 'hero_subline' ) ); ?></p>
			<div class="hero__actions">
				<a class="btn btn--primary" href="<?php echo esc_url( Customizer::get( 'hero_button_url' ) ); ?>"><?php echo esc_html( Customizer::get( 'hero_button' ) ); ?></a>
				<?php $journal = get_category_by_slug( 'journal' ); ?>
				<?php if ( $journal ) : ?>
					<a class="btn btn--ghost" href="<?php echo esc_url( get_category_link( $journal ) ); ?>"><?php esc_html_e( 'Browse the Journal', 'sourov' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<section class="section" id="pillars" aria-label="<?php esc_attr_e( 'Content pillars', 'sourov' ); ?>">
		<div class="container">
			<div class="pillar-grid">
				<?php foreach ( pillar_definitions() as $pillar ) :
					$cat = null;
					foreach ( $pillar['slugs'] as $slug ) {
						$cat = get_category_by_slug( $slug );
						if ( $cat ) {
							break;
						}
					}
					$count = $cat ? (int) $cat->count : 0;
					$link  = $cat ? get_category_link( $cat ) : '';
					$desc  = ( $cat && $cat->description ) ? $cat->description : $pillar['description'];
					?>
					<article class="pillar-card pillar-card--<?php echo esc_attr( $pillar['modifier'] ); ?>">
						<span class="pillar-card__icon" aria-hidden="true"><?php echo esc_html( $pillar['icon'] ); ?></span>
						<h3><?php echo esc_html( $pillar['label'] ); ?></h3>
						<p><?php echo esc_html( $desc ); ?></p>
						<span class="pillar-card__count">
							<?php
							/* translators: %s: number of posts. */
							printf( esc_html( _n( '%s post', '%s posts', $count, 'sourov' ) ), esc_html( number_format_i18n( $count ) ) );
							?>
						</span>
						<?php if ( $link ) : ?>
							<a class="pillar-card__link" href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Enter →', 'sourov' ); ?></a>
						<?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="section section--alt" aria-label="<?php esc_attr_e( 'Latest writing', 'sourov' ); ?>">
		<div class="container">
			<div class="section-head">
				<h2><?php esc_html_e( 'Latest writing', 'sourov' ); ?></h2>
				<?php
				$posts_page = get_option( 'page_for_posts' );
				$all_url    = $posts_page ? get_permalink( $posts_page ) : home_url( '/?post_type=post' );
				?>
				<a class="section-head__link" href="<?php echo esc_url( $all_url ); ?>"><?php esc_html_e( 'See all →', 'sourov' ); ?></a>
			</div>
			<?php
			$latest = new \WP_Query(
				array(
					'post_type'           => 'post',
					'posts_per_page'      => 6,
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
				)
			);
			?>
			<?php if ( $latest->have_posts() ) : ?>
				<div class="post-list">
					<?php
					while ( $latest->have_posts() ) :
						$latest->the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			<?php else : ?>
				<p class="no-results no-results--inline"><?php esc_html_e( 'No posts published yet.', 'sourov' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( class_exists( __NAMESPACE__ . '\\AI_Integration' ) && Customizer::get( 'show_ai_strip' ) ) : ?>
	<section class="section" aria-label="<?php esc_attr_e( 'AI-assisted publishing', 'sourov' ); ?>">
		<div class="container">
			<div class="section-head">
				<h2><?php esc_html_e( 'AI-assisted publishing', 'sourov' ); ?></h2>
			</div>
			<div class="ai-strip">
				<div class="ai-card">
					<h3><?php esc_html_e( 'Content generation', 'sourov' ); ?></h3>
					<p><?php esc_html_e( 'Drafts produced through the AI Gateway land in Posts → Drafts for human review before anything is published.', 'sourov' ); ?></p>
				</div>
				<div class="ai-card">
					<h3><?php esc_html_e( 'Editorial control', 'sourov' ); ?></h3>
					<p><?php esc_html_e( 'Every AI-assisted post carries a visible notice, switched per post by the author.', 'sourov' ); ?></p>
				</div>
				<div class="ai-card">
					<h3><?php esc_html_e( 'Server-side keys', 'sourov' ); ?></h3>
					<p><?php esc_html_e( 'Provider keys for xAI Grok, OpenRouter, and Mistral stay on the server and are never exposed to visitors.', 'sourov' ); ?></p>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>

<?php elseif ( have_posts() ) : ?>

	<div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? 'has-sidebar' : 'no-sidebar'; ?>">
		<div class="content-wrap">
			<div class="content-primary">
				<header class="page-head">
					<h1><?php is_home() ? single_post_title() : the_archive_title(); ?></h1>
				</header>
				<div class="post-list">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
				<?php get_template_part( 'template-parts/pagination' ); ?>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>

<?php else : ?>

	<div class="content-area no-sidebar">
		<div class="content-wrap">
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		</div>
	</div>

<?php endif; ?>

<?php get_footer(); ?>
