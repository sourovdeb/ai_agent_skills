<?php
/**
 * Search results.
 *
 * @package Sourov
 */

get_header();
?>

<div class="content-area no-sidebar">
	<div class="content-wrap">
		<header class="page-head">
			<h1>
				<?php
				/* translators: %s: search query. */
				printf( esc_html__( 'Search results for: %s', 'sourov' ), '<span style="color:var(--accent)">' . esc_html( get_search_query() ) . '</span>' );
				?>
			</h1>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="post-list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				?>
			</div>
			<?php get_template_part( 'template-parts/pagination' ); ?>
		<?php else : ?>
			<div class="no-results">
				<p><?php esc_html_e( 'Nothing matched your search. Try a different phrase.', 'sourov' ); ?></p>
				<?php get_search_form(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php get_footer(); ?>
