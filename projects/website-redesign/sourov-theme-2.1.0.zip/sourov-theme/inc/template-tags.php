<?php
/**
 * Reusable template tags & helpers.
 *
 * @package Sourov
 */

namespace Sourov;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Posted-on date link.
 */
function posted_on() {
	printf(
		'<time class="post-card__date" datetime="%1$s">%2$s</time>',
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() )
	);
}

/**
 * Estimate reading time in minutes from the post content.
 */
function reading_time( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id );
	$words   = str_word_count( wp_strip_all_tags( $content ) );
	$minutes = max( 1, (int) ceil( $words / 200 ) );
	/* translators: %d: minutes. */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'sourov' ), $minutes );
}

/**
 * Related posts: latest N sharing the primary category, excluding the
 * current post. Returns a WP_Query or null.
 */
function related_posts_query( $post_id, $count = 3 ) {
	$cats = get_the_category( $post_id );
	if ( empty( $cats ) ) {
		return null;
	}
	return new \WP_Query(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => (int) $count,
			'post__not_in'        => array( (int) $post_id ),
			'cat'                 => (int) $cats[0]->term_id,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
}
