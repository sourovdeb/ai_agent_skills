<?php
/**
 * Customizer — user-controlled hero copy, accent color, and section toggles.
 * Defaults reproduce the approved v2.0 mockup copy verbatim.
 *
 * @package Sourov
 * @since 2.1.0
 */

namespace Sourov;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Customizer {

	public static function init() {
		add_action( 'customize_register', array( __CLASS__, 'register' ) );
		add_action( 'wp_head', array( __CLASS__, 'output_accent_override' ), 20 );
	}

	public static function defaults() {
		return array(
			'hero_eyebrow'   => __( 'Learn, Teach, Understand', 'sourov' ),
			'hero_title'     => __( 'Learn, Teach, Understand', 'sourov' ),
			'hero_subline'   => __( 'Cambridge CELTA course completed — 120 supervised teaching hours and four written assignments validated to the required standard.', 'sourov' ),
			'hero_button'    => __( 'Explore pillars', 'sourov' ),
			'hero_button_url'=> '#pillars',
			'accent_color'   => '#f59e0b',
			'show_ai_strip'  => true,
		);
	}

	public static function get( $key ) {
		$defaults = self::defaults();
		return get_theme_mod( 'sourov_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}

	public static function register( $wp_customize ) {
		$d = self::defaults();

		$wp_customize->add_section(
			'sourov_theme',
			array(
				'title'    => __( 'Sourov theme', 'sourov' ),
				'priority' => 30,
			)
		);

		$text = array(
			'hero_eyebrow' => __( 'Hero eyebrow', 'sourov' ),
			'hero_title'   => __( 'Hero title', 'sourov' ),
			'hero_button'  => __( 'Hero button label', 'sourov' ),
		);
		foreach ( $text as $key => $label ) {
			$wp_customize->add_setting(
				'sourov_' . $key,
				array(
					'default'           => $d[ $key ],
					'sanitize_callback' => 'sanitize_text_field',
				)
			);
			$wp_customize->add_control(
				'sourov_' . $key,
				array(
					'label'   => $label,
					'section' => 'sourov_theme',
					'type'    => 'text',
				)
			);
		}

		$wp_customize->add_setting(
			'sourov_hero_subline',
			array(
				'default'           => $d['hero_subline'],
				'sanitize_callback' => 'sanitize_textarea_field',
			)
		);
		$wp_customize->add_control(
			'sourov_hero_subline',
			array(
				'label'   => __( 'Hero subline', 'sourov' ),
				'section' => 'sourov_theme',
				'type'    => 'textarea',
			)
		);

		$wp_customize->add_setting(
			'sourov_hero_button_url',
			array(
				'default'           => $d['hero_button_url'],
				'sanitize_callback' => array( __CLASS__, 'sanitize_anchor_or_url' ),
			)
		);
		$wp_customize->add_control(
			'sourov_hero_button_url',
			array(
				'label'       => __( 'Hero button link', 'sourov' ),
				'description' => __( 'URL or #anchor.', 'sourov' ),
				'section'     => 'sourov_theme',
				'type'        => 'text',
			)
		);

		$wp_customize->add_setting(
			'sourov_accent_color',
			array(
				'default'           => $d['accent_color'],
				'sanitize_callback' => 'sanitize_hex_color',
			)
		);
		$wp_customize->add_control(
			new \WP_Customize_Color_Control(
				$wp_customize,
				'sourov_accent_color',
				array(
					'label'   => __( 'Accent color', 'sourov' ),
					'section' => 'sourov_theme',
				)
			)
		);

		$wp_customize->add_setting(
			'sourov_show_ai_strip',
			array(
				'default'           => $d['show_ai_strip'],
				'sanitize_callback' => 'rest_sanitize_boolean',
			)
		);
		$wp_customize->add_control(
			'sourov_show_ai_strip',
			array(
				'label'       => __( 'Show the AI-assisted publishing strip on the front page', 'sourov' ),
				'description' => __( 'Rendered only when the AI Gateway class is active.', 'sourov' ),
				'section'     => 'sourov_theme',
				'type'        => 'checkbox',
			)
		);
	}

	public static function sanitize_anchor_or_url( $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return '#pillars';
		}
		if ( 0 === strpos( $value, '#' ) ) {
			return '#' . sanitize_html_class( substr( $value, 1 ) );
		}
		return esc_url_raw( $value );
	}

	/**
	 * Print a CSS-variable override only when the accent differs
	 * from the shipped default.
	 */
	public static function output_accent_override() {
		$accent  = self::get( 'accent_color' );
		$default = self::defaults();
		if ( ! $accent || strtolower( $accent ) === $default['accent_color'] ) {
			return;
		}
		printf(
			'<style id="sourov-accent">:root{--accent:%1$s;--accent-strong:%1$s;}</style>',
			esc_html( $accent )
		);
	}
}
