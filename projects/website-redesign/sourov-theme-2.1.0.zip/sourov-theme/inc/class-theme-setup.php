<?php
/**
 * Core theme setup: supports, menus, enqueues.
 *
 * @package Sourov
 */

namespace Sourov;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Theme_Setup {

	public static function init() {
		add_action( 'after_setup_theme', array( __CLASS__, 'setup' ) );
		add_action( 'after_setup_theme', array( __CLASS__, 'content_width' ), 0 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_classes' ) );
		add_action( 'wp_head', array( __CLASS__, 'pingback_header' ) );
	}

	public static function setup() {
		load_theme_textdomain( 'sourov', SOUROV_DIR . '/languages' );

		add_theme_support( 'title-tag' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
		add_theme_support( 'custom-logo', array(
			'height'      => 100,
			'width'       => 400,
			'flex-height' => true,
			'flex-width'  => true,
		) );
		add_theme_support( 'custom-background', array( 'default-color' => 'fafbfc' ) );
		add_theme_support( 'post-formats', array( 'aside', 'gallery', 'quote', 'image', 'video' ) );

		add_image_size( 'sourov-featured', 1200, 630, true );
		add_image_size( 'sourov-card', 640, 400, true );

		// Editor stylesheet (guarded — only add if the file exists).
		if ( file_exists( SOUROV_DIR . '/assets/css/editor.css' ) ) {
			add_editor_style( 'assets/css/editor.css' );
		}

		register_nav_menus( array(
			'primary' => __( 'Primary Menu', 'sourov' ),
			'footer'  => __( 'Footer Menu', 'sourov' ),
			'pillar'  => __( 'Pillar Navigation', 'sourov' ),
		) );
	}

	public static function content_width() {
		$GLOBALS['content_width'] = apply_filters( 'sourov_content_width', 1200 );
	}

	public static function scripts() {
		// Main stylesheet (this is where all the design tokens live).
		wp_enqueue_style( 'sourov-style', get_stylesheet_uri(), array(), SOUROV_VERSION );

		// Optional supplementary stylesheet, if present.
		if ( file_exists( SOUROV_DIR . '/assets/css/main.css' ) ) {
			wp_enqueue_style( 'sourov-main', SOUROV_URI . '/assets/css/main.css', array( 'sourov-style' ), SOUROV_VERSION );
		}

		// Front-end JS (mobile nav). Prefer the file; otherwise inline a tiny fallback.
		if ( file_exists( SOUROV_DIR . '/assets/js/main.js' ) ) {
			wp_enqueue_script( 'sourov-main', SOUROV_URI . '/assets/js/main.js', array(), SOUROV_VERSION, true );
		} else {
			wp_register_script( 'sourov-main', '', array(), SOUROV_VERSION, true );
			wp_enqueue_script( 'sourov-main' );
			wp_add_inline_script(
				'sourov-main',
				'document.addEventListener("click",function(e){var t=e.target.closest(".nav-toggle");if(!t)return;var n=document.getElementById("primary-menu");if(!n)return;var o=n.classList.toggle("is-open");t.setAttribute("aria-expanded",o);});'
			);
		}

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}

	public static function body_classes( $classes ) {
		if ( ! is_singular() ) {
			$classes[] = 'archive-view';
		}
		if ( is_active_sidebar( 'sidebar-1' ) && ! is_page() && ! is_front_page() ) {
			$classes[] = 'has-sidebar';
		}
		return $classes;
	}

	public static function pingback_header() {
		if ( is_singular() && pings_open() ) {
			printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
		}
	}
}
