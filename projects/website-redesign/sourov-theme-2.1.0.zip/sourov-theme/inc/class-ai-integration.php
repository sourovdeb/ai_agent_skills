<?php
/**
 * AI Gateway — secure, server-side integration for xAI Grok, OpenRouter,
 * and Mistral (all OpenAI-compatible chat-completions endpoints).
 *
 * Security model (replaces the flawed v1 class):
 *  1. No hardcoded master key. Keys live in a single WP option,
 *     writable and readable only through this class.
 *  2. Keys are NEVER printed to the front end, never localized to JS,
 *     and are masked (last 4 chars) in the admin form.
 *  3. Every AJAX handler checks a nonce AND current_user_can('manage_options').
 *  4. All provider calls are proxied server-side via wp_remote_post.
 *
 * Endpoints (official documentation):
 *  - xAI Grok:   https://api.x.ai/v1/chat/completions      (docs.x.ai)
 *  - OpenRouter: https://openrouter.ai/api/v1/chat/completions (openrouter.ai/docs)
 *  - Mistral:    https://api.mistral.ai/v1/chat/completions (docs.mistral.ai)
 *
 * @package Sourov
 * @since 2.1.0
 */

namespace Sourov;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AI_Integration {

	const OPTION_KEYS = 'sourov_ai_keys';
	const NONCE       = 'sourov_ai_gateway';
	const META_FLAG   = '_sourov_ai_assisted';

	/**
	 * Provider registry. Extensible via the sourov_ai_providers filter.
	 */
	public static function providers() {
		$providers = array(
			'grok' => array(
				'label'       => 'xAI Grok',
				'endpoint'    => 'https://api.x.ai/v1/chat/completions',
				'placeholder' => 'model id per docs.x.ai (e.g. grok-4)',
			),
			'openrouter' => array(
				'label'       => 'OpenRouter',
				'endpoint'    => 'https://openrouter.ai/api/v1/chat/completions',
				'placeholder' => 'vendor/model (e.g. mistralai/mistral-small)',
			),
			'mistral' => array(
				'label'       => 'Mistral',
				'endpoint'    => 'https://api.mistral.ai/v1/chat/completions',
				'placeholder' => 'model id (e.g. mistral-small-latest)',
			),
		);
		return apply_filters( 'sourov_ai_providers', $providers );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_key_save' ) );
		add_action( 'wp_ajax_sourov_ai_test', array( __CLASS__, 'ajax_test' ) );
		add_action( 'wp_ajax_sourov_ai_draft', array( __CLASS__, 'ajax_draft' ) );
		add_filter( 'the_content', array( __CLASS__, 'append_ai_notice' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta_box' ) );
	}

	/* =========================================
	   ADMIN PAGE
	   ========================================= */

	public static function admin_menu() {
		add_options_page(
			__( 'AI Gateway', 'sourov' ),
			__( 'AI Gateway', 'sourov' ),
			'manage_options',
			'sourov-ai-gateway',
			array( __CLASS__, 'render_page' )
		);
	}

	private static function get_keys() {
		$keys = get_option( self::OPTION_KEYS, array() );
		return is_array( $keys ) ? $keys : array();
	}

	/**
	 * Save keys from the settings form. Blank input preserves the stored
	 * key; the literal string "clear" removes it.
	 */
	public static function handle_key_save() {
		if ( ! isset( $_POST['sourov_ai_save_keys'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'sourov' ) );
		}
		check_admin_referer( self::NONCE );

		$stored = self::get_keys();
		foreach ( array_keys( self::providers() ) as $slug ) {
			$field = 'sourov_key_' . $slug;
			if ( ! isset( $_POST[ $field ] ) ) {
				continue;
			}
			$raw = trim( wp_unslash( $_POST[ $field ] ) );
			if ( '' === $raw ) {
				continue; // keep existing
			}
			if ( 'clear' === strtolower( $raw ) ) {
				unset( $stored[ $slug ] );
				continue;
			}
			$stored[ $slug ] = sanitize_text_field( $raw );
		}
		update_option( self::OPTION_KEYS, $stored, false ); // autoload off
		add_settings_error( 'sourov_ai', 'keys_saved', __( 'API keys updated.', 'sourov' ), 'success' );
	}

	private static function mask( $key ) {
		$len = strlen( $key );
		if ( $len <= 4 ) {
			return str_repeat( '•', $len );
		}
		return str_repeat( '•', 12 ) . substr( $key, -4 );
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$keys  = self::get_keys();
		$nonce = wp_create_nonce( self::NONCE );
		settings_errors( 'sourov_ai' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AI Gateway', 'sourov' ); ?></h1>
			<p><?php esc_html_e( 'Keys are stored server-side only, masked below, and never sent to visitors. Leave a field blank to keep the stored key; type "clear" to remove it.', 'sourov' ); ?></p>

			<form method="post">
				<?php wp_nonce_field( self::NONCE ); ?>
				<table class="form-table" role="presentation">
					<?php foreach ( self::providers() as $slug => $p ) : ?>
					<tr>
						<th scope="row"><label for="sourov_key_<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $p['label'] ); ?></label></th>
						<td>
							<input type="password" class="regular-text" autocomplete="off"
								id="sourov_key_<?php echo esc_attr( $slug ); ?>"
								name="sourov_key_<?php echo esc_attr( $slug ); ?>"
								placeholder="<?php echo isset( $keys[ $slug ] ) ? esc_attr( self::mask( $keys[ $slug ] ) ) : esc_attr__( 'not set', 'sourov' ); ?>">
						</td>
					</tr>
					<?php endforeach; ?>
				</table>
				<?php submit_button( __( 'Save keys', 'sourov' ), 'primary', 'sourov_ai_save_keys' ); ?>
			</form>

			<hr>
			<h2><?php esc_html_e( 'Test console', 'sourov' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="sourov-ai-provider"><?php esc_html_e( 'Provider', 'sourov' ); ?></label></th>
					<td>
						<select id="sourov-ai-provider">
							<?php foreach ( self::providers() as $slug => $p ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>" data-placeholder="<?php echo esc_attr( $p['placeholder'] ); ?>"><?php echo esc_html( $p['label'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="sourov-ai-model"><?php esc_html_e( 'Model', 'sourov' ); ?></label></th>
					<td><input type="text" class="regular-text" id="sourov-ai-model" placeholder=""></td>
				</tr>
				<tr>
					<th scope="row"><label for="sourov-ai-prompt"><?php esc_html_e( 'Prompt', 'sourov' ); ?></label></th>
					<td><textarea id="sourov-ai-prompt" class="large-text" rows="5"></textarea></td>
				</tr>
			</table>
			<p>
				<button class="button button-primary" id="sourov-ai-run"><?php esc_html_e( 'Test AI service', 'sourov' ); ?></button>
				<button class="button" id="sourov-ai-make-draft"><?php esc_html_e( 'Generate draft post', 'sourov' ); ?></button>
				<span class="spinner" id="sourov-ai-spinner" style="float:none;"></span>
			</p>
			<pre id="sourov-ai-output" style="background:#111;color:#eee;padding:12px;border-radius:6px;max-height:400px;overflow:auto;white-space:pre-wrap;"></pre>
		</div>
		<script>
		(function(){
			var nonce = <?php echo wp_json_encode( $nonce ); ?>;
			var out = document.getElementById('sourov-ai-output');
			var spin = document.getElementById('sourov-ai-spinner');
			var sel = document.getElementById('sourov-ai-provider');
			var model = document.getElementById('sourov-ai-model');
			function syncPh(){ model.placeholder = sel.options[sel.selectedIndex].dataset.placeholder || ''; }
			sel.addEventListener('change', syncPh); syncPh();
			function call(action){
				spin.classList.add('is-active'); out.textContent = '';
				var body = new URLSearchParams({
					action: action, _ajax_nonce: nonce,
					provider: sel.value, model: model.value,
					prompt: document.getElementById('sourov-ai-prompt').value
				});
				fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: body })
					.then(function(r){ return r.json(); })
					.then(function(j){ out.textContent = JSON.stringify(j, null, 2); })
					.catch(function(e){ out.textContent = 'Request failed: ' + e; })
					.finally(function(){ spin.classList.remove('is-active'); });
			}
			document.getElementById('sourov-ai-run').addEventListener('click', function(e){ e.preventDefault(); call('sourov_ai_test'); });
			document.getElementById('sourov-ai-make-draft').addEventListener('click', function(e){ e.preventDefault(); call('sourov_ai_draft'); });
		})();
		</script>
		<?php
	}

	/* =========================================
	   PROVIDER CALL (server-side only)
	   ========================================= */

	private static function complete( $provider, $model, $prompt ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return new \WP_Error( 'bad_provider', __( 'Unknown provider.', 'sourov' ) );
		}
		$keys = self::get_keys();
		if ( empty( $keys[ $provider ] ) ) {
			return new \WP_Error( 'no_key', __( 'No API key stored for this provider.', 'sourov' ) );
		}
		if ( '' === trim( $model ) || '' === trim( $prompt ) ) {
			return new \WP_Error( 'bad_input', __( 'Model and prompt are required.', 'sourov' ) );
		}

		$headers = array(
			'Authorization' => 'Bearer ' . $keys[ $provider ],
			'Content-Type'  => 'application/json',
		);
		if ( 'openrouter' === $provider ) {
			// Attribution headers per OpenRouter documentation.
			$headers['HTTP-Referer'] = home_url( '/' );
			$headers['X-Title']      = get_bloginfo( 'name' );
		}

		$response = wp_remote_post(
			$providers[ $provider ]['endpoint'],
			array(
				'timeout' => 60,
				'headers' => $headers,
				'body'    => wp_json_encode(
					array(
						'model'    => $model,
						'messages' => array(
							array(
								'role'    => 'user',
								'content' => $prompt,
							),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : sprintf( __( 'Provider returned HTTP %d.', 'sourov' ), $code );
			return new \WP_Error( 'provider_error', $msg, array( 'status' => $code ) );
		}
		if ( empty( $body['choices'][0]['message']['content'] ) ) {
			return new \WP_Error( 'empty_response', __( 'Provider returned no content.', 'sourov' ) );
		}
		return array(
			'content' => $body['choices'][0]['message']['content'],
			'usage'   => isset( $body['usage'] ) ? $body['usage'] : null,
			'model'   => isset( $body['model'] ) ? $body['model'] : $model,
		);
	}

	private static function guard_ajax() {
		check_ajax_referer( self::NONCE );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'sourov' ) ), 403 );
		}
	}

	public static function ajax_test() {
		self::guard_ajax();
		$result = self::complete(
			sanitize_key( $_POST['provider'] ?? '' ),
			sanitize_text_field( wp_unslash( $_POST['model'] ?? '' ) ),
			sanitize_textarea_field( wp_unslash( $_POST['prompt'] ?? '' ) )
		);
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( $result );
	}

	public static function ajax_draft() {
		self::guard_ajax();
		$prompt = sanitize_textarea_field( wp_unslash( $_POST['prompt'] ?? '' ) );
		$result = self::complete(
			sanitize_key( $_POST['provider'] ?? '' ),
			sanitize_text_field( wp_unslash( $_POST['model'] ?? '' ) ),
			$prompt
		);
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		$title   = wp_trim_words( $prompt, 10, '…' );
		$post_id = wp_insert_post(
			array(
				'post_title'   => $title ? $title : __( 'AI draft', 'sourov' ),
				'post_content' => wp_kses_post( $result['content'] ),
				'post_status'  => 'draft',
				'post_author'  => get_current_user_id(),
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
		}
		update_post_meta( $post_id, self::META_FLAG, 1 );
		wp_send_json_success(
			array(
				'draft_id'  => $post_id,
				'edit_link' => get_edit_post_link( $post_id, 'raw' ),
				'content'   => $result['content'],
			)
		);
	}

	/* =========================================
	   AI-ASSISTED NOTICE (per-post flag)
	   ========================================= */

	public static function append_ai_notice( $content ) {
		if ( is_singular( 'post' ) && in_the_loop() && is_main_query()
			&& get_post_meta( get_the_ID(), self::META_FLAG, true ) ) {
			$content .= '<div class="ai-assisted-notice">'
				. esc_html__( 'AI-Assisted Content: This post was enhanced with AI to improve clarity and depth.', 'sourov' )
				. '</div>';
		}
		return $content;
	}

	public static function add_meta_box() {
		add_meta_box(
			'sourov-ai-flag',
			__( 'AI assistance', 'sourov' ),
			array( __CLASS__, 'render_meta_box' ),
			'post',
			'side'
		);
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'sourov_ai_flag', 'sourov_ai_flag_nonce' );
		$checked = get_post_meta( $post->ID, self::META_FLAG, true );
		echo '<label><input type="checkbox" name="sourov_ai_flag" value="1" ' . checked( $checked, 1, false ) . '> '
			. esc_html__( 'Show the AI-assisted notice on this post.', 'sourov' ) . '</label>';
	}

	public static function save_meta_box( $post_id ) {
		if ( ! isset( $_POST['sourov_ai_flag_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sourov_ai_flag_nonce'] ) ), 'sourov_ai_flag' )
			|| ! current_user_can( 'edit_post', $post_id )
			|| ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
			return;
		}
		if ( isset( $_POST['sourov_ai_flag'] ) ) {
			update_post_meta( $post_id, self::META_FLAG, 1 );
		} else {
			delete_post_meta( $post_id, self::META_FLAG );
		}
	}
}
