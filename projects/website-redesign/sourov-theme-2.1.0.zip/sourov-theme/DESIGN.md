# Design Document — Sourov 2.1 "Amber Ledger"

## The movement: Amber Ledger

Documentary order, warmed. A ledger is ruled, dated, and accountable; amber
is lamplight on the page at the end of a working day. The movement joins the
two: dark, quiet surfaces that behave like archival paper at night, ruled
lines that bend under thought but never break, and one warm metal — amber —
spent precisely, never poured. Meticulously crafted restraint is the whole
aesthetic: every radius, every interval on the spacing scale, every opacity
in the texture is a deliberate entry, the product of painstaking attention
rather than default. Master-level execution here means the page reads as
labored over: nothing decorative survives unless it records something true.

Space is generous and vertical; composition is a ledger column widened to a
reading measure. Color carries information before mood: four pillar hues
(blue, violet, amber, green) mark the four documented content pillars and
appear as a single 3-pixel ribbon across the top of every page — the one
signature gesture, repeated in the brand mark's three rising bars (learn,
teach, understand). Scale is fixed to the approved type table; rhythm comes
from the spacing scale, not from improvisation. Hierarchy is serif against
sans: Georgia speaks, Inter records.

### Algorithmic expression (hero texture)

The texture is the ledger's rules passing through weather: twenty-six
horizontal paths displaced by four layered sine fields, seeded at 20260704
so every regeneration is identical — controlled chaos with a reproducible
provenance. Opacity falls off from the center line outward; one line in five
brightens. The algorithm is short, deterministic, and documented in
`tools/generate-texture.py`; refinement went into the falloff so the field
reads at six to fourteen percent presence and never competes with type.

## Token record (grounds)

| Token group | Value | Source |
|---|---|---|
| Accent | #f59e0b / #fbbf24 / #b45309 | User brief 2026-07-04: "yellow and dark"; amber retained from approved v2.0 journal pillar |
| Neutrals | #0f0e0a bg · #17150f surface · #f5efdd ink · #d9d2bd body | Derived warm-dark set for the brief |
| Pillar hues | #3b82f6 · #8b5cf6 · #f59e0b · #10b981 | Approved v2.0 mockup, unchanged |
| Headings | Georgia, serif, bold · h1 2.25rem · h2 1.875rem · h3 1.5rem | Approved v2.0 mockup type table |
| Body | Inter (self-hosted, SIL OFL 1.1) · 1rem | Approved v2.0 mockup; no CDN (GDPR) |
| Spacing | xs .25 · sm .5 · md 1 · lg 1.5 · xl 2 · 2xl 3 rem | Approved v2.0 mockup spacing system |
| Radii | .375rem / .5rem / pill | Approved v2.0 mockup |
| Shadows | 0 1px 3px 0 · 0 10px 15px -3px (darkened alpha) | Approved v2.0 mockup |
| Containers | 1200px desktop · 72ch reading | Approved v2.0 mockup |
| Grid | 3 / 2 / 1 columns desktop / tablet / mobile | Approved v2.0 consistency checklist |
