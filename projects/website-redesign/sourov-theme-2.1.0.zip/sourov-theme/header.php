<?php
/**
 * Header: opens the document and prints the sticky nav.
 *
 * @package Sourov
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'sourov' ); ?></a>

<header class="site-header" role="banner">
	<div class="site-header__inner">
		<div class="site-brand">
			<?php
			if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
				the_custom_logo();
			} else {
				?>
				<p class="site-brand__title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				</p>
				<?php
			}
			?>
		</div>

		<button class="nav-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'sourov' ); ?>">
			<span></span><span></span><span></span>
		</button>

		<nav class="main-nav" id="primary-menu" role="navigation" aria-label="<?php esc_attr_e( 'Primary', 'sourov' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'nav-menu',
						'depth'          => 2,
					)
				);
			} else {
				// Friendly fallback that mirrors the prototype's pill nav.
				echo '<ul class="nav-menu main-nav--fallback">';
				$home_class = is_front_page() ? ' class="current-menu-item"' : '';
				printf( '<li%1$s><a href="%2$s">%3$s</a></li>', $home_class, esc_url( home_url( '/' ) ), esc_html__( 'Home', 'sourov' ) );
				wp_list_pages(
					array(
						'title_li' => '',
						'depth'    => 1,
						'number'   => 4,
					)
				);
				echo '</ul>';
			}
			?>
		</nav>
	</div>
</header>

<main id="main" class="site-main">
