<?php
/**
 * Custom search form.
 *
 * @package Sourov
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="s"><?php esc_html_e( 'Search for:', 'sourov' ); ?></label>
	<input type="search" id="s" class="search-field" placeholder="<?php esc_attr_e( 'Search…', 'sourov' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
	<button type="submit" class="btn btn--primary"><?php esc_html_e( 'Search', 'sourov' ); ?></button>
</form>
