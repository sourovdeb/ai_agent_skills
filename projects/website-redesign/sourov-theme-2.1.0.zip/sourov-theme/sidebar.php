<?php
/**
 * Blog sidebar.
 *
 * @package Sourov
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<aside class="sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'sourov' ); ?>">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>
