/**
 * Sourov theme — front-end scripts.
 */
(function () {
	'use strict';

	// Mobile nav toggle.
	document.addEventListener('click', function (e) {
		var toggle = e.target.closest('.nav-toggle');
		if (!toggle) return;
		var nav = document.getElementById('primary-menu');
		if (!nav) return;
		var open = nav.classList.toggle('is-open');
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
	});

	// Close mobile nav when a link is tapped.
	document.addEventListener('click', function (e) {
		if (e.target.closest('#primary-menu a')) {
			var nav = document.getElementById('primary-menu');
			if (nav) nav.classList.remove('is-open');
		}
	});
})();
