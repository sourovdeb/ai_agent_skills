# Sourov — WordPress Theme (v2.1.0 "Amber Ledger")

Dark, amber-accented, pillar-based theme for teaching, philosophy, and
resources. Responsive from phone to widescreen, self-hosted fonts, and a
secure server-side AI Gateway (xAI Grok, OpenRouter, Mistral) under full
administrator control.

## Install

1. Zip the `sourov-theme` folder (or upload via SFTP to
   `wp-content/themes/sourov`).
2. Appearance → Themes → Activate.
3. Appearance → Menus — create a menu, assign to Primary Menu (and
   optionally Footer Menu). Without one, the header shows a fallback.
4. Appearance → Customize → Sourov theme — hero eyebrow, title, subline,
   button, accent color, and the AI strip toggle.
5. Appearance → Customize → Site Identity — upload
   `assets/img/icon-512.png` as the Site Icon (WordPress generates the
   favicon sizes from it). `favicon.svg`, `favicon.ico`, the PNG set, and
   `apple-touch-icon.png` are also provided for manual `<head>` wiring.
6. Settings → AI Gateway — paste provider keys (see below).

## What changed in 2.1.0

| Area | Change |
|---|---|
| Palette | Yellow-and-dark per brief 2026-07-04; purple gradient removed; pillar hues unchanged |
| Type | Georgia headings + Inter body per approved v2.0 mockup; Inter self-hosted (SIL OFL 1.1, `assets/fonts/`) — no font CDN, no third-party request |
| Tokens | Mockup spacing scale (rem), radii (.375/.5rem), shadows, 1200px container |
| Grids | Cards 3 / 2 / 1 columns (desktop / tablet / mobile); fixed 8:5 card image ratio |
| Front page | Hero (Customizer-controlled) → three pillar cards with live post counts → Latest writing (6) → AI strip (conditional) |
| Archives | Pillar-colored header with icon, filter chips, Recent / A–Z sort (`?sort=az`, whitelisted) |
| Single | Meta line (badge · date · author · reading time), Related reading (3, same category) |
| Footer | WordPress · AI Gateway (when active) · Privacy Policy line |
| Customizer | New "Sourov theme" section: hero copy, button, accent color, AI strip toggle |
| AI Gateway | New `inc/class-ai-integration.php` — see security model below |
| Assets | favicon set, app icons (192/512/maskable/apple-touch), og-image 1200×630, twitter-image 1200×628, seeded hero texture, screenshot.png, theme.json |
| Accessibility | :focus-visible rings, prefers-reduced-motion honored, skip link retained |

## AI Gateway — security model

The v1 class shipped three defects (hardcoded master key, provider key
localized to the browser, AJAX without capability checks). The bundled
class removes all three by construction:

1. Keys live in one non-autoloaded option, entered at Settings → AI
   Gateway, displayed masked (last 4 characters), blank-to-keep,
   "clear"-to-remove. No key is ever hardcoded.
2. No key reaches the front end: no `wp_localize_script`, no REST echo.
   All provider calls are proxied server-side through `wp_remote_post`.
3. Every AJAX handler verifies a nonce and `current_user_can(
   'manage_options' )`. Draft generation writes `post_status => draft`
   only; publication remains a human action.

Providers and official endpoints:

| Provider | Endpoint | Documentation |
|---|---|---|
| xAI Grok | `https://api.x.ai/v1/chat/completions` | docs.x.ai |
| OpenRouter | `https://openrouter.ai/api/v1/chat/completions` | openrouter.ai/docs |
| Mistral | `https://api.mistral.ai/v1/chat/completions` | docs.mistral.ai |

Model identifiers change over time; the model field is free text — copy the
current identifier from the provider's documentation. "OpenClaw" from the
v1 mockup is omitted: no official API documentation could be verified.

Per-post notice: an "AI assistance" checkbox in the post sidebar appends
the documented notice ("AI-Assisted Content: …") through `the_content`.

## Pillars

Cards, badges, and archive headers auto-color by category slug:
`english-teaching` → blue · `philosophy` / `philosophy-mental-health` →
violet · `journal` → amber · `resources` → green. Front-page pillar
descriptions use the category description when set, otherwise the mockup
copy.

## Files

Everything from v2.0.0 plus: `inc/class-ai-integration.php`,
`inc/class-customizer.php`, `theme.json`, `screenshot.png`, `DESIGN.md`,
`assets/fonts/` (Inter + OFL.txt), `assets/img/` (icons, social images,
hero texture), `tools/generate-texture.py` (seeded, deterministic).

Optional drop-ins (`class-pillar-management.php`, `class-auto-menu.php`,
`class-seo-optimizer.php`) are still auto-required and booted when present.
If you re-add your old copies, first fix the two v1 parse errors noted in
review (stray text in `SEO_Optimizer::add_pillar_to_sitemap()`; unclosed
brace in `Auto_Menu::pillar_menu_shortcode()`). Do not re-add the old
`class-ai-integration.php`; it is superseded.

## Recommended next files (not yet built)

`languages/sourov.pot` and a distribution `readme.txt`.
