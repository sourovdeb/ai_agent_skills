<?php
/**
 * Sourov theme functions and definitions.
 *
 * @package Sourov
 * @version 2.0.0
 */

namespace Sourov;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'SOUROV_VERSION', '2.0.0' );
define( 'SOUROV_DIR', get_template_directory() );
define( 'SOUROV_URI', get_template_directory_uri() );

/* =============================================
   LOAD INCLUDES
   ============================================= */
/**
 * Require the inc/* class files if they exist, then boot any that expose
 * a static ::init(). This is the bootstrap that was missing in v1 — without
 * it none of the classes actually hook into WordPress.
 */
$sourov_includes = array(
	'inc/template-tags.php',
	'inc/class-theme-setup.php',
	'inc/class-customizer.php',
	'inc/class-pillar-management.php',
	'inc/class-auto-menu.php',
	'inc/class-ai-integration.php',
	'inc/class-seo-optimizer.php',
);

foreach ( $sourov_includes as $sourov_file ) {
	$sourov_path = SOUROV_DIR . '/' . $sourov_file;
	if ( file_exists( $sourov_path ) ) {
		require_once $sourov_path;
	}
}

/**
 * Boot the feature classes. Each is guarded so dropping any single class
 * file does not fatal the whole theme.
 */
add_action(
	'after_setup_theme',
	function () {
		foreach ( array(
			__NAMESPACE__ . '\\Theme_Setup',
			__NAMESPACE__ . '\\Customizer',
			__NAMESPACE__ . '\\Pillar_Management',
			__NAMESPACE__ . '\\Auto_Menu',
			__NAMESPACE__ . '\\AI_Integration',
			__NAMESPACE__ . '\\SEO_Optimizer',
		) as $class ) {
			if ( class_exists( $class ) && method_exists( $class, 'init' ) ) {
				$class::init();
			}
		}
	},
	1
);

/* =============================================
   WIDGET AREAS
   ============================================= */
add_action(
	'widgets_init',
	function () {
		register_sidebar(
			array(
				'name'          => __( 'Blog Sidebar', 'sourov' ),
				'id'            => 'sidebar-1',
				'description'   => __( 'Shown beside posts and archives.', 'sourov' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => __( 'Footer', 'sourov' ),
				'id'            => 'footer-1',
				'description'   => __( 'Optional widgets shown in the footer.', 'sourov' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
);

/* =============================================
   EXCERPT TUNING
   ============================================= */
add_filter( 'excerpt_length', function () { return 28; }, 999 );
add_filter( 'excerpt_more', function () { return '&hellip;'; } );

/**
 * Map a category slug to its pillar CSS modifier so cards/badges pick up
 * the right pillar color. Keeps template markup tidy.
 */
function pillar_modifier( $slug ) {
	$map = array(
		'english-teaching'          => 'english',
		'philosophy'                => 'philosophy',
		'philosophy-mental-health'  => 'philosophy',
		'journal'                   => 'journal',
		'resources'                 => 'resources',
	);
	return isset( $map[ $slug ] ) ? $map[ $slug ] : '';
}

/**
 * Echo the primary category badge for the current post.
 */
function the_category_badge( $post_id = null ) {
	$cats = get_the_category( $post_id );
	if ( empty( $cats ) ) {
		return;
	}
	$cat  = $cats[0];
	$mod  = pillar_modifier( $cat->slug );
	$class = 'cat-badge' . ( $mod ? ' cat-badge--' . $mod : '' );
	printf(
		'<a class="%1$s" href="%2$s">%3$s</a>',
		esc_attr( $class ),
		esc_url( get_category_link( $cat->term_id ) ),
		esc_html( $cat->name )
	);
}

/**
 * Pillar icon for a category slug. Icons per the approved v2.0 mockup.
 */
function pillar_icon( $slug ) {
	$map = array(
		'english-teaching'         => '📚',
		'philosophy'               => '🧠',
		'philosophy-mental-health' => '🧠',
		'journal'                  => '📓',
		'resources'                => '🔧',
	);
	return isset( $map[ $slug ] ) ? $map[ $slug ] : '';
}

/**
 * The three front-page pillars, exactly as documented in the v2.0 mockup.
 * Descriptions fall back to the mockup copy when the category has none.
 */
function pillar_definitions() {
	return apply_filters(
		'sourov_pillar_definitions',
		array(
			array(
				'label'       => __( 'English Teaching', 'sourov' ),
				'slugs'       => array( 'english-teaching' ),
				'modifier'    => 'english',
				'icon'        => '📚',
				'description' => __( 'Lessons, ELT method posts', 'sourov' ),
			),
			array(
				'label'       => __( 'Philosophy & Mental Health', 'sourov' ),
				'slugs'       => array( 'philosophy-mental-health', 'philosophy' ),
				'modifier'    => 'philosophy',
				'icon'        => '🧠',
				'description' => __( 'Personal essays on meaning', 'sourov' ),
			),
			array(
				'label'       => __( 'Resources', 'sourov' ),
				'slugs'       => array( 'resources' ),
				'modifier'    => 'resources',
				'icon'        => '🔧',
				'description' => __( 'Tools, software with affiliate links', 'sourov' ),
			),
		)
	);
}

/**
 * Alphabetical sort on category archives via ?sort=az (whitelisted).
 */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_category() ) {
			return;
		}
		$sort = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : '';
		if ( 'az' === $sort ) {
			$query->set( 'orderby', 'title' );
			$query->set( 'order', 'ASC' );
		}
	}
);
