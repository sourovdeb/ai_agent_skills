<?php
namespace Sourov;

/**
 * Category / tag / date / author archive.
 * Category archives double as the pillar views: colored header,
 * filter chips, sort links, and a responsive card grid.
 *
 * @package Sourov
 */

get_header();

$pillar_mod  = '';
$pillar_icon = '';
if ( is_category() ) {
	$pillar_mod  = pillar_modifier( get_queried_object()->slug );
	$pillar_icon = pillar_icon( get_queried_object()->slug );
}
?>

<div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? 'has-sidebar' : 'no-sidebar'; ?>">
	<div class="content-wrap">
		<div class="content-primary">
			<header class="page-head <?php echo $pillar_mod ? 'page-head--' . esc_attr( $pillar_mod ) : ''; ?>">
				<h1>
					<?php if ( $pillar_icon ) : ?>
						<span class="page-head__icon" aria-hidden="true"><?php echo esc_html( $pillar_icon ); ?></span>
					<?php endif; ?>
					<?php echo wp_kses_post( get_the_archive_title() ); ?>
				</h1>
				<?php
				$desc = get_the_archive_description();
				if ( $desc ) {
					echo '<p>' . wp_kses_post( $desc ) . '</p>';
				} elseif ( is_category() ) {
					echo '<p>' . esc_html__( 'Daily notes on teaching, thinking, and practice.', 'sourov' ) . '</p>';
				}
				?>
			</header>

			<div class="archive-controls">
				<?php
				$pillars = array(
					'english-teaching' => __( 'English Teaching', 'sourov' ),
					'philosophy'       => __( 'Philosophy', 'sourov' ),
					'journal'          => __( 'Journal', 'sourov' ),
					'resources'        => __( 'Resources', 'sourov' ),
				);
				$current_slug = is_category() ? get_queried_object()->slug : '';
				?>
				<nav class="filter-chips" aria-label="<?php esc_attr_e( 'Filter by pillar', 'sourov' ); ?>">
					<a class="filter-chip <?php echo is_category() ? '' : 'is-active'; ?>" href="<?php echo esc_url( get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' ) ); ?>"><?php esc_html_e( 'All', 'sourov' ); ?></a>
					<?php
					foreach ( $pillars as $slug => $label ) :
						$cat = get_category_by_slug( $slug );
						if ( ! $cat ) {
							continue;
						}
						$active = ( $current_slug === $slug ) ? 'is-active' : '';
						?>
						<a class="filter-chip <?php echo esc_attr( $active ); ?>" href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $label ); ?></a>
					<?php endforeach; ?>
				</nav>

				<?php if ( is_category() ) :
					$sort    = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : 'recent';
					$base    = get_category_link( get_queried_object() );
					?>
					<nav class="sort-links" aria-label="<?php esc_attr_e( 'Sort posts', 'sourov' ); ?>">
						<span><?php esc_html_e( 'Sort:', 'sourov' ); ?></span>
						<a class="<?php echo 'az' !== $sort ? 'is-active' : ''; ?>" href="<?php echo esc_url( $base ); ?>"><?php esc_html_e( 'Recent', 'sourov' ); ?></a>
						<a class="<?php echo 'az' === $sort ? 'is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'sort', 'az', $base ) ); ?>"><?php esc_html_e( 'A–Z', 'sourov' ); ?></a>
					</nav>
				<?php endif; ?>
			</div>

			<?php if ( have_posts() ) : ?>
				<div class="post-list">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					?>
				</div>
				<?php get_template_part( 'template-parts/pagination' ); ?>
			<?php else : ?>
				<p class="no-results no-results--inline"><?php esc_html_e( 'No posts in this category yet.', 'sourov' ); ?></p>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>

<?php get_footer(); ?>
