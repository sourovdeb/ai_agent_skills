#!/usr/bin/env python3
"""
Amber Ledger — seeded generative hero texture (movement: "Amber Ledger").
Ruled ledger lines warped by layered sine fields: documentary order bent,
never broken. Deterministic: seed 20260704 (build date). Output: quiet
amber strokes on transparency, meant for ~6-14% visual presence.
"""
import math, random

SEED = 20260704
random.seed(SEED)

W, H = 1600, 640
LINES = 26
POINTS = 64

def field(x, y, phases):
    v = 0.0
    for (fx, fy, amp, ph) in phases:
        v += amp * math.sin(x * fx + ph) * math.cos(y * fy + ph * 0.7)
    return v

phases = [(random.uniform(0.002, 0.006), random.uniform(0.004, 0.010),
           random.uniform(8, 22), random.uniform(0, math.tau)) for _ in range(4)]

paths = []
for i in range(LINES):
    base_y = H * (i + 0.5) / LINES
    drift = random.uniform(-6, 6)
    pts = []
    for j in range(POINTS + 1):
        x = W * j / POINTS
        y = base_y + drift + field(x, base_y, phases)
        pts.append((x, y))
    d = f"M {pts[0][0]:.1f} {pts[0][1]:.1f} " + " ".join(
        f"L {x:.1f} {y:.1f}" for x, y in pts[1:])
    # Center lines glow slightly warmer; edges recede.
    t = abs((i / (LINES - 1)) - 0.5) * 2
    opacity = 0.16 * (1 - t) + 0.05
    width = 1.4 - 0.6 * t
    color = "#f59e0b" if i % 5 else "#fbbf24"
    paths.append(
        f'<path d="{d}" fill="none" stroke="{color}" '
        f'stroke-opacity="{opacity:.3f}" stroke-width="{width:.2f}"/>')

svg = (
    f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
    f'preserveAspectRatio="xMidYMid slice" role="img" aria-hidden="true">'
    f'<!-- Amber Ledger texture · seed {SEED} · generated, deterministic -->'
    + "".join(paths) + "</svg>"
)

with open("assets/img/hero-texture.svg", "w") as f:
    f.write(svg)
print(f"hero-texture.svg written · {len(svg)/1024:.1f} KB · seed {SEED}")
