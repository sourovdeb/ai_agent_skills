<?php
/**
 * Static page.
 *
 * @package Sourov
 */

get_header();
?>

<div class="content-area no-sidebar">
	<div class="content-wrap">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'page' );

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		endwhile;
		?>
	</div>
</div>

<?php get_footer(); ?>
