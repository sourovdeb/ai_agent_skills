<?php
namespace Sourov;

/**
 * Single post: article, related reading, prev/next, comments.
 *
 * @package Sourov
 */

get_header();
?>

<div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? 'has-sidebar' : 'no-sidebar'; ?>">
	<div class="content-wrap">
		<div class="content-primary">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', 'single' );

				// Related reading — three most recent posts sharing the primary category.
				$related = related_posts_query( get_the_ID(), 3 );
				if ( $related && $related->have_posts() ) :
					?>
					<aside class="related" aria-label="<?php esc_attr_e( 'Related reading', 'sourov' ); ?>">
						<h2><?php esc_html_e( 'Related reading', 'sourov' ); ?></h2>
						<div class="post-list">
							<?php
							while ( $related->have_posts() ) :
								$related->the_post();
								get_template_part( 'template-parts/content', 'card' );
							endwhile;
							wp_reset_postdata();
							?>
						</div>
					</aside>
					<?php
				endif;

				// Prev / next.
				$prev = get_previous_post();
				$next = get_next_post();
				if ( $prev || $next ) :
					?>
					<nav class="post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'sourov' ); ?>">
						<?php if ( $prev ) : ?>
							<a class="nav-prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
								<span class="nav-label"><?php esc_html_e( '← Previous', 'sourov' ); ?></span>
								<?php echo esc_html( get_the_title( $prev ) ); ?>
							</a>
						<?php else : ?><span></span><?php endif; ?>
						<?php if ( $next ) : ?>
							<a class="nav-next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
								<span class="nav-label"><?php esc_html_e( 'Next →', 'sourov' ); ?></span>
								<?php echo esc_html( get_the_title( $next ) ); ?>
							</a>
						<?php else : ?><span></span><?php endif; ?>
					</nav>
					<?php
				endif;

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			endwhile;
			?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>

<?php get_footer(); ?>
