<?php
/**
 * Post card — used in index, archive and search loops.
 *
 * @package Sourov
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="post-card__thumb" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php the_post_thumbnail( 'sourov-card', array( 'loading' => 'lazy', 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
		</a>
	<?php endif; ?>

	<div class="post-card__meta">
		<?php \Sourov\the_category_badge(); ?>
		<span class="post-card__date"><?php echo esc_html( get_the_date() ); ?></span>
		<?php if ( is_sticky() && ( is_home() || is_front_page() ) ) : ?>
			<span class="sticky-badge"><?php esc_html_e( 'Featured', 'sourov' ); ?></span>
		<?php endif; ?>
	</div>

	<h3 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<p class="post-card__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
</article>
