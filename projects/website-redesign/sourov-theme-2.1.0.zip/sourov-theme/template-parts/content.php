<?php
/**
 * Fallback content part (used when no specialised part matches).
 *
 * @package Sourov
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
	<div class="post-card__meta">
		<?php \Sourov\the_category_badge(); ?>
		<span class="post-card__date"><?php echo esc_html( get_the_date() ); ?></span>
	</div>
	<h3 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<p class="post-card__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
</article>
