<?php
/**
 * Page content.
 *
 * @package Sourov
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-page' ); ?>>
	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(); ?></h1>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
		<figure class="entry-featured">
			<?php the_post_thumbnail( 'sourov-featured' ); ?>
		</figure>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();
		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'sourov' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>
</article>
