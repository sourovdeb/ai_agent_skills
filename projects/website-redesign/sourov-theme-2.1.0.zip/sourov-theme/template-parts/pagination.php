<?php
/**
 * Numbered pagination for archives and the blog index.
 *
 * @package Sourov
 */

$links = paginate_links(
	array(
		'type'      => 'array',
		'prev_text' => __( '←', 'sourov' ),
		'next_text' => __( '→', 'sourov' ),
	)
);

if ( ! empty( $links ) ) {
	echo '<nav class="pagination" aria-label="' . esc_attr__( 'Posts navigation', 'sourov' ) . '">';
	foreach ( $links as $link ) {
		echo wp_kses_post( $link );
	}
	echo '</nav>';
}
