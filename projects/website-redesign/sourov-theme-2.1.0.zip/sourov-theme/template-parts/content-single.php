<?php
/**
 * Single post content — meta line per mockup:
 * [pillar badge] date • author • reading time.
 *
 * @package Sourov
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
	<header class="entry-header">
		<div class="post-card__meta">
			<?php \Sourov\the_category_badge(); ?>
			<time class="post-card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			<span class="post-card__date">&bull; <?php echo esc_html( get_the_author() ); ?></span>
			<span class="post-card__date">&bull; <?php echo esc_html( \Sourov\reading_time() ); ?></span>
		</div>
		<h1 class="entry-title"><?php the_title(); ?></h1>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
		<figure class="entry-featured">
			<?php the_post_thumbnail( 'sourov-featured', array( 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
		</figure>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();
		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'sourov' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>

	<footer class="entry-footer">
		<?php
		$tags = get_the_tag_list( '<span class="tag-links">', '', '</span>' );
		if ( $tags ) {
			echo wp_kses_post( $tags );
		}
		if ( get_comments_number() ) {
			printf(
				'<p>%s</p>',
				esc_html( sprintf( _n( '%s comment', '%s comments', get_comments_number(), 'sourov' ), number_format_i18n( get_comments_number() ) ) )
			);
		}
		?>
	</footer>
</article>
