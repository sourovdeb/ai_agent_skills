<?php
/**
 * Empty state — no posts found.
 *
 * @package Sourov
 */
?>
<div class="no-results">
	<h1><?php esc_html_e( 'Nothing here yet', 'sourov' ); ?></h1>
	<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
		<p>
			<?php
			printf(
				wp_kses( __( 'Ready to publish your first post? <a href="%s">Get started here</a>.', 'sourov' ), array( 'a' => array( 'href' => array() ) ) ),
				esc_url( admin_url( 'post-new.php' ) )
			);
			?>
		</p>
	<?php else : ?>
		<p><?php esc_html_e( 'Try a search, or come back soon.', 'sourov' ); ?></p>
		<div style="max-width:420px;margin:24px auto;"><?php get_search_form(); ?></div>
	<?php endif; ?>
</div>
