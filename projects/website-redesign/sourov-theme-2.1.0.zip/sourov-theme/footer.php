<?php
namespace Sourov;

/**
 * Footer: closes #main and prints the site footer.
 * Meta line per the approved mockup: WordPress · AI Gateway · Privacy Policy.
 *
 * @package Sourov
 */
?>
</main><!-- #main -->

<footer class="site-footer" role="contentinfo">
	<div class="site-footer__inner">
		<?php
		if ( has_nav_menu( 'footer' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'container'      => 'nav',
					'menu_class'     => 'footer-menu',
					'depth'          => 1,
				)
			);
		}
		?>
		<p class="site-footer__copy">
			&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'sourov' ); ?>
		</p>
		<p class="site-footer__tag"><?php echo esc_html( get_bloginfo( 'description' ) ?: __( 'Learn, Teach, Understand', 'sourov' ) ); ?></p>
		<p class="site-footer__meta">
			<a href="https://wordpress.org/" rel="nofollow"><?php esc_html_e( 'Powered by WordPress', 'sourov' ); ?></a>
			<?php if ( class_exists( __NAMESPACE__ . '\\AI_Integration' ) ) : ?>
				<span class="sep">|</span><span><?php esc_html_e( 'AI Gateway', 'sourov' ); ?></span>
			<?php endif; ?>
			<?php if ( get_privacy_policy_url() ) : ?>
				<span class="sep">|</span><?php the_privacy_policy_link(); ?>
			<?php endif; ?>
		</p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
